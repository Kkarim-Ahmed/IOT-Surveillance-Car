#!/usr/bin/env python3
"""
Simple Face Detection Test
Tests BlazeFace detection without face recognition
"""

import cv2
import time
from collections import deque
import config
from camera_utils import open_camera, read_frame
from blazeface_detector import BlazeFaceDetector

def main():
    print("=" * 60)
    print("🚀 Simple Face Detection Test (BlazeFace)")
    print("=" * 60)
    
    # Initialize detector
    print("📦 Loading BlazeFace detector...")
    try:
        detector = BlazeFaceDetector()
        print("✅ BlazeFace loaded successfully")
    except Exception as e:
        print(f"❌ Failed to load BlazeFace: {e}")
        return
    
    # Initialize camera
    print("📷 Opening camera...")
    cap = open_camera()
    if not cap.isOpened():
        print("❌ Failed to open camera")
        return
    
    print(f"✅ Camera opened: {config.FRAME_WIDTH}x{config.FRAME_HEIGHT}")
    
    # Performance tracking
    fps_queue = deque(maxlen=30)
    frame_count = 0
    
    print("\n" + "=" * 60)
    print("▶️  Starting face detection...")
    print("   Press 'q' to quit")
    print("   Press 's' to save screenshot")
    print("=" * 60 + "\n")
    
    try:
        while True:
            start_time = time.time()
            
            # Capture frame
            ret, frame = read_frame(cap)
            if not ret:
                print("❌ Failed to capture frame")
                break
            
            # Detect faces
            face_locations = detector.detect_faces(frame)
            
            # Draw results
            annotated = frame.copy()
            
            for i, (top, right, bottom, left) in enumerate(face_locations):
                # Draw bounding box
                cv2.rectangle(annotated, (left, top), (right, bottom), (0, 255, 0), 2)
                
                # Draw label
                label = f"Face {i+1}"
                cv2.putText(
                    annotated,
                    label,
                    (left, top - 10),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.6,
                    (0, 255, 0),
                    2
                )
                
                # Draw center point
                center_x = (left + right) // 2
                center_y = (top + bottom) // 2
                cv2.circle(annotated, (center_x, center_y), 5, (0, 255, 0), -1)
            
            # Draw frame center crosshair
            frame_h, frame_w = frame.shape[:2]
            center_x, center_y = frame_w // 2, frame_h // 2
            cv2.line(annotated, (center_x - 20, center_y), (center_x + 20, center_y), (255, 0, 0), 2)
            cv2.line(annotated, (center_x, center_y - 20), (center_x, center_y + 20), (255, 0, 0), 2)
            
            # Calculate FPS
            elapsed = time.time() - start_time
            fps = 1.0 / elapsed if elapsed > 0 else 0
            fps_queue.append(fps)
            avg_fps = sum(fps_queue) / len(fps_queue)
            
            # Draw FPS and face count
            cv2.putText(
                annotated,
                f"FPS: {avg_fps:.1f}",
                (10, 30),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (0, 255, 0),
                2
            )
            
            cv2.putText(
                annotated,
                f"Faces: {len(face_locations)}",
                (10, 60),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (0, 255, 0),
                2
            )
            
            # Display
            cv2.imshow("Face Detection Test - Press 'q' to quit", annotated)
            
            # Handle keyboard
            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                print("\n⏹️  Stopping...")
                break
            elif key == ord('s'):
                filename = f"test_capture_{int(time.time())}.jpg"
                cv2.imwrite(filename, annotated)
                print(f"📸 Saved: {filename}")
            
            frame_count += 1
            
            # Print stats every 30 frames
            if frame_count % 30 == 0:
                print(f"📊 Frame {frame_count}: {avg_fps:.1f} FPS, {len(face_locations)} face(s) detected")
    
    except KeyboardInterrupt:
        print("\n⏹️  Interrupted by user")
    
    finally:
        cap.release()
        cv2.destroyAllWindows()
        print("\n✅ Test complete")
        print(f"📊 Final stats: {frame_count} frames processed, avg {avg_fps:.1f} FPS")

if __name__ == "__main__":
    main()
