# 🚀 Quick Test Guide for Mizo's AI System

## Step 1: Install Dependencies

### Option A: Full Installation (Recommended)
```bash
cd zLast_development/Mizo/IOT-Surveillance-Car-merged-ai-computer-vision

# Install all dependencies
pip3 install -r requirements.txt
```

**Note**: This will take 30-60 minutes on first install because:
- `dlib` needs to compile from source
- `face-recognition` depends on dlib
- Large packages like `mediapipe` and `ultralytics`

### Option B: Minimal Test (Faster - 5 minutes)
```bash
# Install only essential packages for basic testing
pip3 install opencv-python numpy mediapipe imutils
```

This skips face recognition but lets you test face detection.

## Step 2: Configure for Testing

Edit `config.py` and set:
```python
IS_RASPBERRY_PI = False  # We're testing on Mac
ENABLE_SERVO_CONTROL = False  # No servo hardware yet
FLIP_HORIZONTAL = True  # For webcam mirror correction
```

## Step 3: Run Tests

### Test 1: Simple Face Detection (No Recognition)
```bash
python3 main.py --detector blazeface
```

**What you'll see:**
- Camera window opens
- Orange boxes around detected faces
- "Unknown" labels (no recognition yet)
- FPS counter

**Controls:**
- Press `q` to quit
- Press `s` to save screenshot
- Press `r` to reset (does nothing without servos)

### Test 2: GUI Application
```bash
python3 gui_tracker.py
```

**What you'll see:**
- GUI window with controls
- Live camera feed
- Mode selection buttons
- System info panel

### Test 3: Check Camera
```bash
python3 -c "import cv2; cap = cv2.VideoCapture(0); print('Camera OK' if cap.isOpened() else 'Camera FAILED'); cap.release()"
```

## Step 4: Test Face Recognition (After Full Install)

### Enroll a Face
```bash
# Method 1: From camera
python3 enroll_faces.py --mode camera --name "YourName" --count 5

# Method 2: From images
python3 enroll_faces.py --mode images --name "YourName" --images photo1.jpg photo2.jpg
```

### Run with Recognition
```bash
python3 main.py --detector blazeface
```

Now you'll see:
- Green boxes for recognized faces
- Your name displayed
- Confidence score

## 🐛 Troubleshooting

### Camera Not Found
```bash
# List cameras
ls /dev/video*

# Test with OpenCV
python3 -c "import cv2; print([i for i in range(10) if cv2.VideoCapture(i).isOpened()])"
```

### Import Errors
```bash
# Check what's installed
pip3 list | grep -E "(opencv|mediapipe|face|numpy)"

# Reinstall specific package
pip3 install --upgrade opencv-python
```

### Slow Performance
Edit `config.py`:
```python
FRAME_WIDTH = 320
FRAME_HEIGHT = 240
PROCESS_EVERY_N_FRAMES = 10  # Process every 10th frame
```

### dlib Installation Fails
```bash
# Install build tools first
brew install cmake  # macOS
# or
sudo apt-get install cmake  # Linux

# Then retry
pip3 install dlib
```

## 📊 Expected Performance (MacBook)

- **BlazeFace Detection**: 30+ FPS
- **Face Recognition**: 10-15 FPS
- **Memory Usage**: ~300 MB
- **CPU Usage**: 40-60%

## 🎯 Quick Test Checklist

- [ ] Python 3.7+ installed
- [ ] Camera connected and working
- [ ] Dependencies installed
- [ ] `config.py` configured
- [ ] Camera window opens
- [ ] Faces detected (orange boxes)
- [ ] Can quit with 'q'
- [ ] (Optional) Face recognition working

## 💡 Next Steps After Testing

1. **If detection works**: Install full requirements for recognition
2. **If recognition works**: Enroll multiple people
3. **For Raspberry Pi**: Transfer code and test on Pi
4. **For servo control**: Connect PCA9685 and servos
5. **For integration**: Merge with MQTT system

## 🆘 Need Help?

**Camera issues:**
- Check camera permissions
- Try different CAMERA_INDEX (0, 1, 2)
- Test with Photo Booth or other camera app

**Performance issues:**
- Reduce resolution
- Increase frame skipping
- Use BlazeFace instead of YOLO

**Installation issues:**
- Use virtual environment
- Check Python version (3.7-3.11 recommended)
- Install system dependencies first
