#!/usr/bin/env python3
"""
Setup Test Script
Checks if system is ready to run Mizo's AI system
"""

import sys
import subprocess

def check_python_version():
    """Check Python version"""
    print("=" * 60)
    print("🐍 Checking Python Version")
    print("=" * 60)
    
    version = sys.version_info
    print(f"Python {version.major}.{version.minor}.{version.micro}")
    
    if version.major == 3 and version.minor >= 7:
        print("✅ Python version OK")
        return True
    else:
        print("❌ Python 3.7+ required")
        return False

def check_package(package_name, import_name=None):
    """Check if a package is installed"""
    if import_name is None:
        import_name = package_name
    
    try:
        __import__(import_name)
        print(f"✅ {package_name}")
        return True
    except ImportError:
        print(f"❌ {package_name} - NOT INSTALLED")
        return False

def check_dependencies():
    """Check all required dependencies"""
    print("\n" + "=" * 60)
    print("📦 Checking Dependencies")
    print("=" * 60)
    
    packages = {
        "opencv-python": "cv2",
        "numpy": "numpy",
        "mediapipe": "mediapipe",
        "Pillow": "PIL",
        "imutils": "imutils",
        "face-recognition": "face_recognition",
        "dlib": "dlib",
        "ultralytics": "ultralytics",
        "scipy": "scipy"
    }
    
    installed = []
    missing = []
    
    for package, import_name in packages.items():
        if check_package(package, import_name):
            installed.append(package)
        else:
            missing.append(package)
    
    print(f"\n📊 Summary: {len(installed)}/{len(packages)} packages installed")
    
    if missing:
        print(f"\n⚠️  Missing packages: {', '.join(missing)}")
        print("\nTo install missing packages:")
        print(f"pip3 install {' '.join(missing)}")
    
    return len(missing) == 0

def check_camera():
    """Check if camera is available"""
    print("\n" + "=" * 60)
    print("📷 Checking Camera")
    print("=" * 60)
    
    try:
        import cv2
        
        # Try to open camera
        cap = cv2.VideoCapture(0)
        
        if cap.isOpened():
            ret, frame = cap.read()
            cap.release()
            
            if ret:
                print("✅ Camera detected and working")
                print(f"   Frame size: {frame.shape[1]}x{frame.shape[0]}")
                return True
            else:
                print("⚠️  Camera detected but cannot read frames")
                return False
        else:
            print("❌ Cannot open camera")
            print("\nTroubleshooting:")
            print("1. Check camera is connected")
            print("2. Check camera permissions")
            print("3. Try different camera index in config.py")
            return False
            
    except ImportError:
        print("❌ OpenCV not installed - cannot test camera")
        return False
    except Exception as e:
        print(f"❌ Camera test failed: {e}")
        return False

def check_config():
    """Check configuration file"""
    print("\n" + "=" * 60)
    print("⚙️  Checking Configuration")
    print("=" * 60)
    
    try:
        import config
        
        print(f"✅ config.py loaded")
        print(f"   Camera: {config.CAMERA_INDEX}")
        print(f"   Resolution: {config.FRAME_WIDTH}x{config.FRAME_HEIGHT}")
        print(f"   Raspberry Pi Mode: {config.IS_RASPBERRY_PI}")
        print(f"   Servo Control: {config.ENABLE_SERVO_CONTROL}")
        print(f"   Flip Horizontal: {config.FLIP_HORIZONTAL}")
        print(f"   Flip Vertical: {config.FLIP_VERTICAL}")
        
        return True
        
    except ImportError:
        print("❌ config.py not found")
        return False
    except Exception as e:
        print(f"❌ Error loading config: {e}")
        return False

def check_models():
    """Check if AI models are available"""
    print("\n" + "=" * 60)
    print("🤖 Checking AI Models")
    print("=" * 60)
    
    import os
    
    models_to_check = [
        ("Face Encodings", "known_faces/encodings.pkl"),
        ("YOLO Model", "yolov8n-face.pt"),
        ("Known Faces Dir", "known_faces/images")
    ]
    
    for name, path in models_to_check:
        if os.path.exists(path):
            print(f"✅ {name}: {path}")
        else:
            print(f"⚠️  {name}: {path} - NOT FOUND (optional)")
    
    return True

def suggest_next_steps(all_ok, camera_ok, deps_ok):
    """Suggest what to do next"""
    print("\n" + "=" * 60)
    print("🎯 Next Steps")
    print("=" * 60)
    
    if all_ok:
        print("✅ System is ready!")
        print("\nYou can now run:")
        print("  python3 main.py --detector blazeface")
        print("  python3 gui_tracker.py")
        
    elif camera_ok and not deps_ok:
        print("⚠️  Camera works but missing dependencies")
        print("\nInstall missing packages:")
        print("  pip3 install -r requirements.txt")
        print("\nOr for quick test (no face recognition):")
        print("  pip3 install opencv-python numpy mediapipe imutils")
        
    elif deps_ok and not camera_ok:
        print("⚠️  Dependencies OK but camera not working")
        print("\nTroubleshooting:")
        print("1. Check camera connection")
        print("2. Check camera permissions")
        print("3. Try: ls /dev/video*")
        print("4. Edit config.py and change CAMERA_INDEX")
        
    else:
        print("❌ System not ready")
        print("\nInstall dependencies first:")
        print("  pip3 install -r requirements.txt")
        print("\nThen fix camera issues")

def main():
    """Main test function"""
    print("\n" + "=" * 60)
    print("🧪 Mizo's AI System - Setup Test")
    print("=" * 60)
    
    # Run all checks
    python_ok = check_python_version()
    deps_ok = check_dependencies()
    camera_ok = check_camera()
    config_ok = check_config()
    models_ok = check_models()
    
    all_ok = python_ok and deps_ok and camera_ok and config_ok
    
    # Summary
    print("\n" + "=" * 60)
    print("📊 Test Summary")
    print("=" * 60)
    print(f"Python Version:  {'✅' if python_ok else '❌'}")
    print(f"Dependencies:    {'✅' if deps_ok else '❌'}")
    print(f"Camera:          {'✅' if camera_ok else '❌'}")
    print(f"Configuration:   {'✅' if config_ok else '❌'}")
    print(f"Models:          {'✅' if models_ok else '⚠️  (optional)'}")
    
    # Suggest next steps
    suggest_next_steps(all_ok, camera_ok, deps_ok)
    
    print("\n" + "=" * 60)
    
    return 0 if all_ok else 1

if __name__ == "__main__":
    sys.exit(main())
