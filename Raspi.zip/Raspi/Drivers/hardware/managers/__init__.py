"""Hardware management module"""
