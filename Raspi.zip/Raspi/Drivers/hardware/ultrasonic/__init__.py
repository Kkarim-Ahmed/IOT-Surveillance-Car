"""Ultrasonic sensor module"""
