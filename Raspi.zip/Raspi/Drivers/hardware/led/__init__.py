"""LED control module"""
