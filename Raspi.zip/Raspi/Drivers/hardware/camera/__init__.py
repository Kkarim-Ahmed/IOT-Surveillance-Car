"""Camera control module"""
