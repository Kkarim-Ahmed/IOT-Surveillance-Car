"""GPIO management module"""
