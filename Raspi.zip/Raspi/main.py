#!/usr/bin/env python3
"""
Main Entry Point for Surveillance Car System
Orchestrates hardware, network, and AI components
"""

import sys
import signal
import time
from pathlib import Path

# Add current directory to path
sys.path.insert(0, str(Path(__file__).parent))

from Drivers.hardware.managers.hardware_manager import hardware_manager
from Network.MQTT.mqtt_device_controller_integrated import MQTTDeviceController


class SurveillanceCarSystem:
    """
    Main system orchestrator for the surveillance car
    
    Manages:
    - Hardware initialization and control
    - MQTT network communication
    - System lifecycle and graceful shutdown
    """
    
    def __init__(self, broker_host="localhost", broker_port=1883):
        self.broker_host = broker_host
        self.broker_port = broker_port
        self.running = False
        
        # Components
        self.mqtt_controller = None
        
        # Setup signal handlers for graceful shutdown
        self._setup_signal_handlers()
    
    def _setup_signal_handlers(self):
        """Setup handlers for graceful shutdown"""
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)
    
    def _signal_handler(self, signum, frame):
        """Handle shutdown signals"""
        print(f"\n[SYSTEM] Received signal {signum}, initiating shutdown...")
        self.running = False
    
    def initialize(self):
        """Initialize all system components"""
        print("=" * 60)
        print("Surveillance Car System - Initializing")
        print("=" * 60)
        
        try:
            # Initialize hardware manager
            print("[SYSTEM] Initializing hardware...")
            hardware_manager.initialize()
            print("[SYSTEM] Hardware initialized successfully")
            
            # Initialize MQTT controller
            print("[SYSTEM] Initializing MQTT controller...")
            self.mqtt_controller = MQTTDeviceController(
                self.broker_host,
                self.broker_port
            )
            print("[SYSTEM] MQTT controller initialized")
            
            print("=" * 60)
            print("[SYSTEM] All components initialized successfully")
            print("=" * 60)
            return True
            
        except Exception as e:
            print(f"[SYSTEM] Initialization failed: {e}")
            return False
    
    def run(self):
        """Run the surveillance car system"""
        if not self.initialize():
            print("[SYSTEM] Failed to initialize - exiting")
            return 1
        
        try:
            self.running = True
            print("[SYSTEM] System running. Press Ctrl+C to exit.")
            print("=" * 60)
            
            # Start MQTT controller (blocks until stopped)
            self.mqtt_controller.start()
            
        except KeyboardInterrupt:
            print("\n[SYSTEM] Keyboard interrupt received")
        
        except Exception as e:
            print(f"[SYSTEM] Critical error: {e}")
            import traceback
            traceback.print_exc()
            return 1
        
        finally:
            self.shutdown()
        
        return 0
    
    def shutdown(self):
        """Graceful shutdown of all components"""
        print("\n" + "=" * 60)
        print("[SYSTEM] Shutting down surveillance car system...")
        print("=" * 60)
        
        # Stop MQTT controller
        if self.mqtt_controller:
            try:
                self.mqtt_controller.stop()
            except Exception as e:
                print(f"[SYSTEM] MQTT shutdown warning: {e}")
        
        # Cleanup hardware
        try:
            hardware_manager.cleanup()
        except Exception as e:
            print(f"[SYSTEM] Hardware cleanup warning: {e}")
        
        print("[SYSTEM] Shutdown complete")
        print("=" * 60)


def main():
    """Application entry point"""
    # Configuration - can be loaded from config file
    BROKER_HOST = "localhost"  # Change to your MQTT broker IP
    BROKER_PORT = 1883
    
    # Create and run system
    system = SurveillanceCarSystem(BROKER_HOST, BROKER_PORT)
    return system.run()


if __name__ == "__main__":
    sys.exit(main())
